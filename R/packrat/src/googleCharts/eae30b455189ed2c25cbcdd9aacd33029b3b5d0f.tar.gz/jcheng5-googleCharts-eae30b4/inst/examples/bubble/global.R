data <- readRDS("healthexp.Rds")
data$Region <- as.factor(data$Region)
